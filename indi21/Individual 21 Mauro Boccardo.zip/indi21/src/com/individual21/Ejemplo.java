package com.individual21;

//@Mauro Boccardo
//tambien esta arreglado el nombre de paquete
//formatie y arreglela sangria, las llaves finalizadas
//las clases debe ser simple con la primera en mayuscula si espacios entre el metodo
public class Ejemplo {
	// espacio entre parentecis y llave
	public static void main(String args[]) {
		/*
		 * corregi las variables que siempre deben ir en minuscula y sin signos "$", los
		 * cortes de linea deben ir despues de "," o de operador no mas de 80 caracteres
		 */
		int saldo = 5;
		String var1 = "En un lugar de la Mancha, " + "de cuyo nombre no quiero acordarme, "
				+ "no ha mucho tiempo que vivía un hidalgo de los de lanza en astillero, "
				+ "adarga antigua, rocín flaco y galgo corredor. " + "Una olla de algo más vaca que carnero,"
				+ "salpicón las más noches, duelos y quebrantos los sábados,"
				+ "lantejas los viernes, algún palomino de añadidura los domingos,"
				+ "consumían las tres partes de su hacienda.";
		// arregle el comentario de bloque

		// la variable debe ser inicializada en el momento de su declaracion
		int otraCosa = 6;
		// cambie los nombres de las variables para que coincidan las enunciadas antes
		System.out.println("El valor de la primera variable es " + saldo + " y de la segunda es " + otraCosa);
		// cambie los nombres de las variables para que coincidan las enunciadas antes
		System.out.println("¿Te cuento un cuento?: " + var1);
	}
}