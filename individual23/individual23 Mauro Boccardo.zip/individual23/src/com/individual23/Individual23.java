package com.individual23;
import java.util.Scanner;
/*Mauro Boccardo
 *  con el metodo StringBuilder creo una nueva String con los caracteres añadidos
 *  con el  .append(). el bucle for es para recorrer el string y ver uno a uno, luego con el
 *  if hago condiciones (mayor o menor) y que transforme.
 *  con isWhitespace() creo la condicion de que si hay espacio en blanco salte y continue.
 *  agrega el nuevo caracter e imprime la nueva cadena
 *  finalmente,
 */
public class Individual23 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("por favor ingrese texto a analizar");
		String texto = scanner.nextLine();
		scanner.close();
		
		StringBuilder nueva =new StringBuilder();
		for (int i = 0; i <texto.length(); i++) {
			char cara = texto.charAt(i);
			System.out.print(" | original: ->" + texto.charAt(i));
			
			if (texto.charAt(i) == texto.toLowerCase().charAt(i)) {
				nueva.append(Character.toUpperCase(cara));
				System.out.print(" |Mayuscula: ->" + texto.toUpperCase().charAt(i));
			} else if (texto.charAt(i) == texto.toUpperCase().charAt(i)) {
				System.out.print(" |Minuscula: -> " + texto.toLowerCase().charAt(i));
				nueva.append(Character.toLowerCase(cara));
			} else if (Character.isWhitespace(cara)){
				continue;
			}
			else {
				nueva.append(cara);
			}
			
		
		}
		System.out.print("nueva cadena: " + nueva.toString());
	}	
		
	}

