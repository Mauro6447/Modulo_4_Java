package com.individual25;
/*
 * Mauro Boccardo Salvo
 */

public class Individual25 {
//atributos
     String nombres;
     String apellidos;
     String rut;
     int telefono;
     int edad;

    // Constructor vacío
    public void Trabajador() {
    }

    // Constructor con  atributos
    public void Trabajador(String nombres, String apellidos, String rut, int telefono, int edad) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.rut = rut;
        this.telefono = telefono;
        this.edad = edad;
    }

    // Método toString()
    
    public String toString() {
        return "Trabajador[" +
                "nombres -> " + nombres + '*' +
                ", apellidos *" + apellidos + '*' +
                ", rut *" + rut + '*' +
                ", telefono *" + telefono + '*' +
                ", edad=" + edad +
                ']';
    }

    // Método nombreCompleto()
    public String nombreCompleto() {
        return nombres + " " + apellidos;
    }

    // Método descomponerRun()
    public int descomponerRut() {
        String[] parts = rut.split("-");
        String rutSinGuion = parts[rut.length()];
        return Integer.parseInt(rutSinGuion);
    }
}
	
	
	

