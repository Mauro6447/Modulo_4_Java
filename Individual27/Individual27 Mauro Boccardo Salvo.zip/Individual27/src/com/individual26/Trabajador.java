package com.individual26;
/*
 * Mauro Boccardo Salvo
 * 
 * agregue el private y getters y setters para acceder
 */

public class Trabajador {
//atributos
   private  String nombres;
   private  String apellidos;
   private  String rut;
   private  int telefono;
   private  int edad;
 


	// Constructor vacío
    public void Trabajador() {
    }

    // Constructor con  atributos
    public  Trabajador(String nombres, String apellidos, String rut, int telefono, int edad) {
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.rut = rut;
        this.telefono = telefono;
        this.edad = edad;
    }
 // Getters y setters
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }


    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    // Método toString()
    
    public String toString() {
        return "Trabajador[" +
                "nombres -> " + nombres + '*' +
                ", apellidos *" + apellidos + '*' +
                ", rut *" + rut + '*' +
                ", telefono *" + telefono + '*' +
                ", edad=" + edad +
                ']';
    }

    // Método nombreCompleto()
    public String nombreCompleto() {
        return nombres + " " + apellidos;
    }

    // Método descomponerRut()
    public int descomponerRut() {
        String[] parts = rut.split("-");
        String rutSinGuion = parts[rut.length()];
        return Integer.parseInt(rutSinGuion);
    }
}
	
	
	

