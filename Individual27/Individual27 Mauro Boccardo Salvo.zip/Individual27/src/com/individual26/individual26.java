package com.individual26;
/*
 * @Mauro Boccardo Salvo
 */
public class individual26 {

	public static void main(String[] args) {

		
		Trabajador trabajador1 = new Trabajador("gabriel","moya","17698702-2",94648273, 22);
		Trabajador trabajador2 = new Trabajador("jose","moreno","1864243-4",93456252,62);
		Trabajador trabajador3 = new Trabajador("laura","vasconcello","4367789-0",96252622,31);
		
		
		System.out.print(trabajador1.toString());
		System.out.print(trabajador2.toString());
		System.out.print(trabajador3.toString());
		
	}

}
